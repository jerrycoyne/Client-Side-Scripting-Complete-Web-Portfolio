package model.baseballStadiums;

import model.baseballStadiums.*;
import dbUtils.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbMods {

    /*
    Returns a "StringData" object that is full of field level validation
    error messages (or it is full of all empty strings if inputData
    totally passed validation.  
     */
    private static StringData validate(StringData inputData) {

        StringData errorMsgs = new StringData();

      
        // Validation
        
        errorMsgs.stadiumName = ValidationUtils.stringValidationMsg(inputData.stadiumName, 45, true);
        errorMsgs.stadiumCity = ValidationUtils.stringValidationMsg(inputData.stadiumCity, 45, true);
        errorMsgs.stadiumCapacity = ValidationUtils.decimalValidationMsg(inputData.stadiumCapacity, false);
        errorMsgs.stadiumAddress = ValidationUtils.stringValidationMsg(inputData.stadiumAddress, 45, true);
        errorMsgs.stadiumImage = ValidationUtils.stringValidationMsg(inputData.stadiumImage, 145, true);

        return errorMsgs;
    } // validate 

    public static StringData insert(StringData inputData, DbConn dbc) {

        StringData errorMsgs = new StringData();
        errorMsgs = validate(inputData);
        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { // all fields passed validation

            /*
                       String sql = "SELECT web_user_id, user_email, user_password, membership_fee, birthday, "+
                    "web_user.user_role_id, user_role_type "+
                    "FROM web_user, user_role where web_user.user_role_id = user_role.user_role_id " + 
                    "ORDER BY web_user_id ";
             */
            // Start preparing SQL statement
            String sql = "INSERT INTO baseball_stadiums (stadium_name, stadium_city, stadium_capacity, stadium_picture, stadium_address) "
                    + "values (?,?,?,?,?)";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PrepStatement pStatement = new PrepStatement(dbc, sql);

            // Encode string values into the prepared statement (wrapper class).
            pStatement.setString(1, inputData.stadiumName); // string type is simple
            pStatement.setString(2, inputData.stadiumCity);
            pStatement.setBigDecimal(3, ValidationUtils.decimalConversion(inputData.stadiumCapacity));
            pStatement.setString(4, inputData.stadiumImage);
            pStatement.setString(5, inputData.stadiumAddress);
             

            // here the SQL statement is actually executed
            int numRows = pStatement.executeUpdate();

            // This will return empty string if all went well, else all error messages.
            errorMsgs.errorMsg = pStatement.getErrorMsg();
            if (errorMsgs.errorMsg.length() == 0) {
                if (numRows == 1) {
                    errorMsgs.errorMsg = ""; // This means SUCCESS. Let the user interface decide how to tell this to the user.
                } else {
                    // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                    errorMsgs.errorMsg = numRows + " records were inserted when exactly 1 was expected.";
                }
            } else if (errorMsgs.errorMsg.contains("Duplicate entry")) {
                errorMsgs.errorMsg = "That email address is already taken";
            }

        } // all fields passed validation
        return errorMsgs;
    } // insert
    
   // here you would also add methods for update and delete

} // class
