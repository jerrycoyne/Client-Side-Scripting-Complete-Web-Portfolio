package view;

// classes imported from java.sql.*
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.baseballStadiums.*;

// classes in my project
import dbUtils.*;

public class baseballStadiumView {
    
    public static StringDataList getAllStadiums(DbConn dbc) {

        //PreparedStatement stmt = null;
        //ResultSet results = null;
        StringDataList sdl = new StringDataList();
        try {
            String sql = "SELECT stadium_picture, stadium_capacity, stadium_name, stadium_city, stadium_address, id_baseball_stadiums FROM FA18_3344_tuj20794.baseball_stadiums ";  // always order by something, not just random order.
            PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
            ResultSet results = stmt.executeQuery();
            while (results.next()) {
                sdl.add(results);
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            StringData sd = new StringData();
            sd.errorMsg = "Exception thrown in baseballStadiumsView.allUsersAPI(): " + e.getMessage();
            sdl.add(sd);
        }
        return sdl;
    }
    
}
