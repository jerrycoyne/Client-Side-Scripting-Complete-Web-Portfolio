"use strict";

function makePicGallery(id, array) {
    var imgcontainer = array;
    var galleryEle = document.getElementById(id); // get reference to element on the page
    var large = document.getElementById("fullsize"); //big image div 
    var small = document.getElementById("list"); //small image div
    var para = document.getElementById("c");  //caption
    var bigPic = document.createElement("img");  //creates the big picture itself
    bigPic.src = imgcontainer[0].imgFileName;
    large.appendChild(bigPic);
    para.innerHTML = imgcontainer[0].caption;
    for (var i = 0; i < imgcontainer.length; i++) {
        {
            var tinyPic = document.createElement("img"); //creates each tiny picture
            tinyPic.src = imgcontainer[i].imgFileName;
            tinyPic.caption = imgcontainer[i].caption;
            small.appendChild(tinyPic);
            tinyPic.onclick = function () { 
                bigPic.src = this.src;
                para.innerHTML = this.caption;
            };
        }
    }
}

