var d=myApp = angular.module('myApp', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.
            when('/', {
                templateUrl: 'htmlPartials/homeContent.html',
                controller: 'demoController'
            }).
            when('/home', {
                templateUrl: 'htmlPartials/homeContent.html',
                controller: 'demoController'
            }).
            when('/users', {
                templateUrl: 'htmlPartials/listUsers.html',
                controller: 'userController'
            }).
            when('/stadiums', {
                templateUrl: 'htmlPartials/listStadium.html',
                controller: 'stadiumController'
            }).
            otherwise({
                redirectTo: '/'
            });
});


// Each routing rule needs a controller, even if the controller doesn't do anything...
myApp.controller('myApp', function ( ) {

}); // end of def'n of the controller function 